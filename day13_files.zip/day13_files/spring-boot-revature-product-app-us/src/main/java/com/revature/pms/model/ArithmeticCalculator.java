package com.revature.pms.model;

public class ArithmeticCalculator {

		public int add(int num1,int num2) {
			return num1+num2;
		}
		
		public String getMessage() {
			return "Hello and welcome to REVATURE App";
		}
}
