package com.revature.pms.model;

import java.util.HashMap;
import java.util.HashMap;
import java.util.Map;

public class Demo {

	Map<Product,Integer> employees = new HashMap<Product,Integer>();
	
	
	final int marks;
	
	public Demo() {
		marks=99;
	}
	public Demo(int i) {
		marks=999;
	}
	
}
