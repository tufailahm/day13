package com.selenium.training.steps;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.selenium.training.factory.HomePage_PageFactory;
import com.selenium.training.factory.LoginPage_PageFactory;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginValidate_POM {

	public static String browser = "chrome";
	public static WebDriver driver;
	LoginPage_PageFactory loginPage_PageFactory;
	HomePage_PageFactory homePage_PageFactory;

	@Given("browser is opened")
	public void browser_is_opened() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		loginPage_PageFactory = new LoginPage_PageFactory(driver);
		homePage_PageFactory = new HomePage_PageFactory(driver); 
		// Here we are calling login page cons and assigning driver
		System.out.println("browser is opened - done");
	}

	@And("user is on login page")
	public void user_is_on_login_page() {
		System.out.println("user is on login page - done");
		driver.navigate().to("https://example.testproject.io/web/");
	}
	@When("^user enters (.*) and (.*)$")
	public void user_enters_username_and_password(String username, String password) {
		loginPage_PageFactory.enterUsername(username);
		loginPage_PageFactory.enterPassword(password);
	}

	@And("user clicks on login button")
	public void user_clicks_on_login_button() {
		loginPage_PageFactory.clickLogin();
	}
	@Then("user is navigated to the home page")
	public void user_is_navigated_to_the_home_page() {
		boolean result = homePage_PageFactory.checkLogoutDisplayed();
		Assert.assertEquals(true, result);
		driver.close();
		driver.quit();
	}

}
